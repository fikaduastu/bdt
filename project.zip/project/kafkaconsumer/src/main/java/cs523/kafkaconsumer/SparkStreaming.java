package cs523.kafkaconsumer;

import java.io.IOException;
import java.util.*;

import kafka.serializer.StringDecoder;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.streaming.*;
import org.apache.spark.streaming.api.java.*;
import org.apache.spark.streaming.kafka.*;

import com.google.gson.Gson;


public class SparkStreaming 
{
	public static void main( String[] args ) throws IOException
    {
        System.out.println( "starting spark steaming!" );
        SparkConf sconf = new SparkConf()
        	.setAppName("KafkaStreamConsumer")
        	.setMaster("local[*]");
		sconf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer");
		sconf.registerKryoClasses(new Class[]{org.apache.hadoop.hbase.io.ImmutableBytesWritable.class});
		
        JavaSparkContext jsc = new JavaSparkContext(sconf);
        JavaStreamingContext ssc = new JavaStreamingContext(jsc, Durations.seconds(10));
    	
    	HbaseTableUtil hbaseUtil  = new HbaseTableUtil(jsc, "local");
    	
    	try {

    	    Set<String> topics = new HashSet<>(Arrays.asList("coinmarkets".split(",")));
    		Map<String, String> kafkaParams = new HashMap<>();
    	    kafkaParams.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
    	    kafkaParams.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "StringDeserializer");
    		kafkaParams.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "StringDeserializer");
    		kafkaParams.put(ConsumerConfig.GROUP_ID_CONFIG, "group1");
    	    
    		JavaPairInputDStream<String, String> stream = 
					KafkaUtils.createDirectStream(ssc, String.class, String.class, StringDecoder.class, StringDecoder.class, kafkaParams, topics);
    		
    		stream.foreachRDD(rdd -> {
			
				JavaRDD<CoinMarkets> coinMarketsRDD = rdd.map(record -> new Gson().fromJson(record._2, CoinMarkets.class));
				hbaseUtil.writeRowNewHadoopAPI(coinMarketsRDD);
    		});

    		ssc.start();
    		ssc.awaitTermination();
//    		jsc.sc().stop();
    		
//	    	
	    	
        } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println( "complete spark stream!" );
    }
}
