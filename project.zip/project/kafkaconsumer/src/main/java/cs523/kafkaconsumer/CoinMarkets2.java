package cs523.kafkaconsumer;

import java.io.Serializable;

public class CoinMarkets2 implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1971130583205888523L;
    private String id;
    private String symbol;
    private String name;
    private long current_price;
    private long market_cap;
    private long market_cap_rank;
    private long total_volume;
    private double price_change_percentage_24h;
    private double market_cap_change_percentage_24h;
    private String last_updated;
    private double price_change_percentage_1h_in_currency;
    
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getCurrent_price() {
		return current_price;
	}
	public void setCurrent_price(long current_price) {
		this.current_price = current_price;
	}
	public long getMarket_cap() {
		return market_cap;
	}
	public void setMarket_cap(long market_cap) {
		this.market_cap = market_cap;
	}
	public long getMarket_cap_rank() {
		return market_cap_rank;
	}
	public void setMarket_cap_rank(long market_cap_rank) {
		this.market_cap_rank = market_cap_rank;
	}
	public long getTotal_volume() {
		return total_volume;
	}
	public void setTotal_volume(long total_volume) {
		this.total_volume = total_volume;
	}
	public double getPrice_change_percentage_24h() {
		return price_change_percentage_24h;
	}
	public void setPrice_change_percentage_24h(double price_change_percentage_24h) {
		this.price_change_percentage_24h = price_change_percentage_24h;
	}
	public double getMarket_cap_change_percentage_24h() {
		return market_cap_change_percentage_24h;
	}
	public void setMarket_cap_change_percentage_24h(
			double market_cap_change_percentage_24h) {
		this.market_cap_change_percentage_24h = market_cap_change_percentage_24h;
	}
	public String getLast_updated() {
		return last_updated;
	}
	public void setLast_updated(String last_updated) {
		this.last_updated = last_updated;
	}
	public double getPrice_change_percentage_1h_in_currency() {
		return price_change_percentage_1h_in_currency;
	}
	public void setPrice_change_percentage_1h_in_currency(
			double price_change_percentage_1h_in_currency) {
		this.price_change_percentage_1h_in_currency = price_change_percentage_1h_in_currency;
	}

}
