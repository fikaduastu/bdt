package cs523.kafkaconsumer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

public class SparkSqlHbase {
	private static final String TABLE_NAME = "coinmarkets";
	private static final String CF_DEFAULT = "coins";
	static Configuration config;
	static JavaSparkContext jsc;
	public static void main(String[] args) {

		SparkConf sconf = new SparkConf().setAppName("KafkaStreamConsumer4")
				.setMaster("local[3]");
		sconf.set("spark.serializer",
				"org.apache.spark.serializer.KryoSerializer");
		sconf.registerKryoClasses(new Class[] { org.apache.hadoop.hbase.io.ImmutableBytesWritable.class });
		
		config = HBaseConfiguration.create();
		config.addResource(new Path("file:///etc/hbase/conf.dist/hbase-site.xml"));
		config.addResource(new Path("file:///etc/hbase/conf.cloudera.hbase/hbase-site.xml"));
		config.set(TableInputFormat.INPUT_TABLE, TABLE_NAME);

		jsc = new JavaSparkContext(sconf);
		SQLContext sqlContext = new SQLContext(jsc.sc());
		
		JavaPairRDD<ImmutableBytesWritable, Result> hBaseRDD = readTableByJavaPairRDD();
		System.out.println("Number of register in hbase table: " + hBaseRDD.count());
		
		//build hbase table schema
		JavaRDD<CoinMarkets2> rows = hBaseRDD.map(x -> {
			CoinMarkets2 cms = new CoinMarkets2();
			
			cms.setId(Bytes.toString(x._1.get())); //row-key
			cms.setSymbol(Bytes.toString(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("symbol")))); 
			cms.setName(Bytes.toString(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("name"))));
			cms.setCurrent_price(Bytes.toLong(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("current_price"))));
			cms.setMarket_cap(Bytes.toLong(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("market_cap"))));
			cms.setMarket_cap_rank(Bytes.toLong(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("market_cap_rank"))));
			cms.setTotal_volume(Bytes.toLong(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("total_volume"))));
			cms.setPrice_change_percentage_24h(Bytes.toDouble(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("price_change_percentage_24h"))));
			cms.setMarket_cap_change_percentage_24h(Bytes.toDouble(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("market_cap_change_24h_percentage"))));
			cms.setLast_updated(Bytes.toString(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("last_updated"))));
			cms.setPrice_change_percentage_1h_in_currency(Bytes.toDouble(x._2.getValue(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("price_change_percentage_1h_in_currency"))));
			
			return cms;
		});

		DataFrame tabledata = sqlContext
				.createDataFrame(rows, CoinMarkets2.class);
		tabledata.registerTempTable(TABLE_NAME);
		tabledata.printSchema();

		// Query 1 
		DataFrame query1 = sqlContext
				.table(TABLE_NAME)
				.select("*")
				.orderBy("market_cap_rank")
				.limit(10);
		query1.show();

		// Query 2 SELECT avg(total_volume) as average_total_volume FROM coinmarkets
		DataFrame query2 = sqlContext
				.sql("SELECT avg(total_volume) as average_total_volume FROM coinmarkets");
		query2.show();

		// Query 3  "SELECT name, price_change_percentage_1h_in_currency, price_change_percentage_24h, last_updated FROM coinmarkets LIMIT 10"
		 DataFrame query3 = sqlContext
				 .table(TABLE_NAME)
				 .select("name", "price_change_percentage_1h_in_currency", "price_change_percentage_24h", "last_updated")
				 .limit(10);
		 query3.show();
		 
		// Query 4 
			DataFrame query4 = sqlContext
					.table(TABLE_NAME)
					.select("*")
					.filter("current_price > 1000")
					.orderBy()
					.limit(10);
			query4.show();

		jsc.stop();

	}
	
	//get the Result of query from the Table of Hbase
    public static JavaPairRDD<ImmutableBytesWritable, Result> readTableByJavaPairRDD() {
		
    	JavaPairRDD<ImmutableBytesWritable, Result> hBaseRDD = jsc
				.newAPIHadoopRDD(
						config,
						TableInputFormat.class,
						org.apache.hadoop.hbase.io.ImmutableBytesWritable.class,
						org.apache.hadoop.hbase.client.Result.class);
		return hBaseRDD;
    }
	

}
