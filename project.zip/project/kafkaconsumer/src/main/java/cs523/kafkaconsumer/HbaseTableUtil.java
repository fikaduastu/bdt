package cs523.kafkaconsumer;

import java.io.IOException;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.io.compress.Compression.Algorithm;
import org.apache.hadoop.hbase.mapred.TableOutputFormat;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.mapreduce.Job;

import scala.Tuple2;


public class HbaseTableUtil 
{

	private static final String TABLE_NAME = "coinmarkets";
	private static final String CF_DEFAULT = "coins";
	static Configuration config;
	JavaSparkContext jsc;
	String mode;
	Job jobConfig;
	
	public HbaseTableUtil (JavaSparkContext jsc, String mode) {
		this.jsc = jsc;
		this.mode = mode;
		config = HBaseConfiguration.create();
		config.addResource(new Path("file:///etc/hbase/conf.dist/hbase-site.xml"));
		config.addResource(new Path("file:///etc/hbase/conf.cloudera.hbase/hbase-site.xml"));
		config.set(TableInputFormat.INPUT_TABLE, TABLE_NAME);
		
		try {
			jobConfig = Job.getInstance(config);
			jobConfig.getConfiguration().set(TableOutputFormat.OUTPUT_TABLE, TABLE_NAME);
			jobConfig.setOutputFormatClass(org.apache.hadoop.hbase.mapreduce.TableOutputFormat.class);
			
			this.initialize(config);
		
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
    
	public void initialize(Configuration config)
    {
        System.out.println( "init spark hbase!" );

        try (Connection conn = ConnectionFactory.createConnection(config);
        	Admin admin  = conn.getAdmin();) {
        	
        	

			System.out.print("Creating table.... ");
        	HTableDescriptor table = new HTableDescriptor(TableName.valueOf(TABLE_NAME));
			table.addFamily(new HColumnDescriptor(CF_DEFAULT).setCompressionType(Algorithm.NONE));
			
			if (admin.tableExists(table.getTableName()))
			{
				System.out.print("table already created.... ");
//				admin.disableTable(table.getTableName());
//				admin.deleteTable(table.getTableName());
			}else 
				admin.createTable(table);

			System.out.println(" Done!");
        } catch (IOException e) {
			e.printStackTrace();
		}
    }   
    void writeRowNewHadoopAPI(JavaRDD<CoinMarkets> records) {
    	JavaPairRDD<ImmutableBytesWritable, Put> hbasePuts = 
    			records.mapToPair(x -> {
					CoinMarkets cms = x;
    				Put put = new Put(Bytes.toBytes(cms.getId())); //rowKey
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("symbol"), Bytes.toBytes(cms.getSymbol())); 
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("name"), Bytes.toBytes(cms.getName()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("current_price"), Bytes.toBytes(cms.getCurrentPrice()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("market_cap"), Bytes.toBytes(cms.getMarketCap()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("market_cap_rank"), Bytes.toBytes(cms.getMarketCapRank()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("total_volume"), Bytes.toBytes(cms.getTotalVolume()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("price_change_percentage_24h"), Bytes.toBytes(cms.getPriceChangePercentage24h()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("market_cap_change_24h_percentage"), Bytes.toBytes(cms.getMarketCapChangePercentage24h()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("last_updated"), Bytes.toBytes(cms.getLastUpdated()));
					put.addColumn(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("price_change_percentage_1h_in_currency"), Bytes.toBytes(cms.getPriceChangePercentage1hInCurrency()));
					
    				return new Tuple2<ImmutableBytesWritable, Put>(
						new ImmutableBytesWritable(), put);});
 		hbasePuts.saveAsNewAPIHadoopDataset(jobConfig.getConfiguration());
    }
}
