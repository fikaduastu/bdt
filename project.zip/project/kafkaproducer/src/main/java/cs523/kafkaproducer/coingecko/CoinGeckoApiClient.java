package cs523.kafkaproducer.coingecko;

import java.util.List;

import cs523.kafkaproducer.coingecko.domain.Ping;
import cs523.kafkaproducer.coingecko.domain.Coins.CoinMarkets;

public interface CoinGeckoApiClient {
    Ping ping();

    List<CoinMarkets> getCoinMarkets(String vsCurrency);
}
