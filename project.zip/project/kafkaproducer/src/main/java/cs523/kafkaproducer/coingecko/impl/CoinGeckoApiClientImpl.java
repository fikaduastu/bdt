package cs523.kafkaproducer.coingecko.impl;

import java.util.List;

import cs523.kafkaproducer.coingecko.CoinGeckoApi;
import cs523.kafkaproducer.coingecko.CoinGeckoApiClient;
import cs523.kafkaproducer.coingecko.CoinGeckoApiService;
import cs523.kafkaproducer.coingecko.domain.Ping;
import cs523.kafkaproducer.coingecko.domain.Coins.CoinMarkets;

public class CoinGeckoApiClientImpl implements CoinGeckoApiClient {
    private CoinGeckoApiService coinGeckoApiService;
    private CoinGeckoApi coinGeckoApi;

    public CoinGeckoApiClientImpl(){
        this.coinGeckoApi = new CoinGeckoApi();
        this.coinGeckoApiService = coinGeckoApi.createService(CoinGeckoApiService.class);

    }

    
    public Ping ping(){
        return coinGeckoApi.executeSync(coinGeckoApiService.ping());
    }

    public List<CoinMarkets> getCoinMarkets(String vsCurrency) {
        return getCoinMarkets(vsCurrency,null,null, 20,null,false,null);
    }


    public List<CoinMarkets> getCoinMarkets(String vsCurrency, String ids, String order, Integer perPage, Integer page, boolean sparkline, String priceChangePercentage) {
        return coinGeckoApi.executeSync(coinGeckoApiService.getCoinMarkets(vsCurrency,ids,order,perPage,page,sparkline,priceChangePercentage));
    }
}
