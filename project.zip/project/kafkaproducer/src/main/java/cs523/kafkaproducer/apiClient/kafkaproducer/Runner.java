package cs523.kafkaproducer.apiClient.kafkaproducer;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.google.gson.Gson;

import cs523.kafkaproducer.coingecko.CoinGeckoApiClient;
import cs523.kafkaproducer.coingecko.domain.Coins.CoinMarkets;
import cs523.kafkaproducer.coingecko.impl.CoinGeckoApiClientImpl;

public class Runner 
{
    public static void main( String[] args )
    {	
    	KProducer kProducer = new KProducer();
        
        final KafkaProducer<String, String> producer = kProducer.getKafkaMarketPriceProducer();
    	final CoinGeckoApiClient apiClient = new CoinGeckoApiClientImpl();
    	final List<CoinMarkets> markets = new ArrayList<CoinMarkets>();
    	
    	//API calls at timer intervals
        new Timer().schedule(new TimerTask() {
            public void run()  {
            	markets.clear();
            	List<CoinMarkets> markets = apiClient.getCoinMarkets("usd");
            	
            	for(CoinMarkets m: markets){
            		String marketsMessage = new Gson().toJson(m);
            		
            		System.out.println(marketsMessage);
            		
            		ProducerRecord<String, String> producerRecord = new ProducerRecord<String, String>("coinmarkets", "marketPrice", marketsMessage);
            		producer.send(producerRecord);
            	}
            	
            }
        }, 1, 10000 * 3); //10 seconds
    	//producer.close();
   }
}
