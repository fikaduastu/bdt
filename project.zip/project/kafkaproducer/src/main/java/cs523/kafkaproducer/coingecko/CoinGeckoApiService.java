package cs523.kafkaproducer.coingecko;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import cs523.kafkaproducer.coingecko.domain.Ping;
import cs523.kafkaproducer.coingecko.domain.Coins.CoinMarkets;

public interface CoinGeckoApiService {
    @GET("ping")
    Call<Ping> ping();
    
    @GET("coins/markets")
    Call<List<CoinMarkets>> getCoinMarkets(@Query("vs_currency") String vsCurrency, @Query("ids") String ids,
                                           @Query("order") String order, @Query("per_page") Integer perPage,
                                           @Query("page") Integer page, @Query("sparkline") boolean sparkline,
                                           @Query("price_change_percentage") String priceChangePercentage);

}
