# Big Data Pipeline for Real-Time Cryptocurrency Dataset



### Prerequisites
* Cloudera VM image
* Linux machine

### Configuration
* Install and run kafka
    * kafka-server-start.sh $KAFKA_HOME/config/server.properties
    * **Note:** Zookeeper is already running
* Make sure HBase servers are running
    * **confirm servers are up:** service --status-all
    * **start master server:** sudo service hbase-master start;
    * **start region H-Region server** sudo service hbase-regionserver start;
* Install Tableau Desktop for your machine
  * Download ODBC driver
  * Connect to Hive Server with username:cloudera
  
### Data Repository => Kafka producer(topic:coinsmarket)
* [CoinGecko API](https://www.coingecko.com/api/documentations/v3#/)
* Endpoint: **/coins/markets**
    * List all supported coins price, market cap, volume and market related data
    * limited to 20 records for this use case    
    * curl -X 'GET' \
      'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&sparkline=false' \
      -H 'accept: application/json'
      
## SparkStreaming <= Kafka consumer(topic:coinsmarket)
* Use this to obtain all the coins market data (price, market cap, volume)

### HBase => Hive Table
* Create an external table on Hive to query HBase Data
  * **Query:**
    * CREATE EXTERNAL TABLE IF NOT EXISTS coinmarkets (
      id STRING, symbol STRING, name STRING, current_price BIGINT, market_cap BIGINT ,
      market_cap_rank BIGINT, total_volume BIGINT, price_change_percentage_24h DOUBLE,
      market_cap_change_24h_percentage DOUBLE, last_updated STRING,
      price_change_percentage_1h_in_currency DOUBLE
      )
      STORED BY 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
      WITH SERDEPROPERTIES (
      'hbase.columns.mapping' = ':key, coins:symbol, coins:name, coins:current_price#b,
      coins:market_cap#b, coins:market_cap_rank#b, coins:total_volume#b, coins:price_change_percentage_24h#b, coins:market_cap_change_24h_percentage#b, coins:last_updated, coins:price_change_percentage_1h_in_currency#b'
      )
      TBLPROPERTIES ('hbase.table.name' = 'coinmarkets');
* Column mapping and serialization 
    * **Hive/HBase Serde:** 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
  
### Hive views/table & Tableau Visualization
* Connected outside VM via VM Ip and Hive port(default:10000)
* Worksheets for
  * Coins Market Capitalization
  *

### Spark SQL <= HBase
* Plain queries
  * DataFrame query2 = sqlContext
      .sql("SELECT avg(total_volume) as average_total_volume FROM coinmarkets");
      query2.show();
* Functional Queries
  * DataFrame query4 = sqlContext
    .table(TABLE_NAME)
    .select("*")
    .filter("current_price > 1000")
    .orderBy()
    .limit(10);
    query4.show();

### RUN Projects
1. kafkaproducer
  * Run **Runner.java** class for streaming data from API to kafka queue
2. kafkaconsumer
  * Run **SparkStreaming.java** class for kafka consumer + spark streaming to HBase
  * Run **SparkSqlHbase.java** class to connect spark SQL to HBase and query table
3. Alternatively in pseudo-distributed mode
   * **package jar:** cd to project folder, run 'mvn clean package'
   * **spark-submit:** submit jars to spark on terminal